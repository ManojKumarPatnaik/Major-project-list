Recognition for Projects
=========================

### Throughout July

Ever since this repo was created, it has been in the top list on GH. Be it the daily or weekly list!

Projects is the #5 most forked repo on GH done in Python language!

![](https://raw.github.com/thekarangoel/Projects/master/RECOGNITION/top-languages-python-2013-07-25.png)

### July 25 2013

In the monthly top list on GH.

![Showed up on top monthly list](https://raw.github.com/thekarangoel/Projects/master/RECOGNITION/top5-monthly-2013-07-25.png)

### July 14 2013

Just 10 days after the repo was created, it showed up in the top 5 on GH.

![](https://raw.github.com/thekarangoel/Projects/master/RECOGNITION/top5-2013-07-14.png)

Check other screenshots in this repo for more GH explore page rankings following that day.